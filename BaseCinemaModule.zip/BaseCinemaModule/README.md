# BaseCinemaModule
### -----DFC影城 购票App 插件化基类-----</br>
1、基类搭建 从彩虹馆App基类迁移</br>
