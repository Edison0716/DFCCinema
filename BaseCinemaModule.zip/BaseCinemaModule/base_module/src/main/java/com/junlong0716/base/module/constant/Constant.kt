package com.junlong0716.base.module.constant

/**
 *@author: EdsionLi
 *@description:
 *@date: Created in 2018/8/16 下午4:18
 *@modified by:
 */
object Constant {
    const val ACCOUNT_LOG_OUT = "ACCOUNT_LOG_OUT" //账号过期
}