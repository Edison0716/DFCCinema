package com.junlong0716.base.module.entity

/**
 *@author: 巴黎没有摩天轮Li
 *@description: 登录后返回的个人信息实体
 *@date: Created in 下午9:55 2018/3/15
 *@modified by:
 */

class UserAccountEntity(var accountCode:Int, var sex:String, var headImg:String, var imToken:String, var nickName:String, var pin:String)