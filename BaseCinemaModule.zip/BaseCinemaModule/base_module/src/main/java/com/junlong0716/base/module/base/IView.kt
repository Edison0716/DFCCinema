package com.junlong0716.base.module.base

interface IView
