package com.junlong0716.base.module.glide;

/**
 * @author: 巴黎没有摩天轮Li
 * @description:
 * @date: Created in 下午8:31 2017/12/26
 * @modified by:
 */
public interface ProgressListener {
    void onProgress(int progress);
}