package com.junlong0716.base.module.http.entity

/**
 *@author: EdsionLi
 *@description:
 *@date: Created in 2018/3/30 上午10:12
 *@modified by:
 */
class BasicResponseEntity(var code: Int, var desc: String, var data: Any)